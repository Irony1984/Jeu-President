# Président de Club — Phase 1 (Première boucle jouable)

Jeu jouable : une saison de 2e division (Serie B), des matchs, un classement.
Architecture du chapitre 13 (GameState + Managers + Game Engine).

## Lancer
Ouvrir `index.html` dans Chrome (Android ou ordinateur). Aucun serveur, aucun build.

## Ce qui marche en Phase 1
- Créer un club parmi la Serie B, avec une réputation de départ.
- **Le Bureau** : date, saison, trésorerie, confiance du Board, réputation.
- **Le classement** de 2e division (18 clubs), mis à jour après chaque journée.
- **Bouton « Continuer »** : avance jusqu'à la prochaine journée.
- **Écran de match** : fil d'événements commenté qui se déroule, avec bouton
  **« Simuler »** pour sauter directement au résultat (ch. 12). Le Président
  observe, il n'agit pas (R001).
- **Boucle de saison complète** : 34 journées, puis fin de saison.
- Sauvegarde **IndexedDB** : fermer/rouvrir reprend la partie.

## Test de fin de Phase 1
1. Créer un club → le Bureau et le classement s'affichent.
2. « Continuer » → les journées s'enchaînent, le classement évolue.
3. À votre journée, l'écran de match s'ouvre : regarder le fil OU « Simuler ».
4. Aller au bout de la saison (34 journées) → « Fin de saison ».
5. Fermer/rouvrir → la partie reprend. ✅

## Clubs (À CORRIGER LIBREMENT)
Le fichier `js/data/clubs-serie-b.js` contient la liste des clubs et leur force.
Les noms viennent d'une connaissance datée (début 2025) : remplace-les par les
vrais noms à jour quand tu veux, sans toucher au code.

## Structure
```
president-de-club/
├── index.html
├── css/style.css
└── js/
    ├── gamestate.js        état central
    ├── storage.js          sauvegarde IndexedDB
    ├── engine.js           Game Engine (cycle Continuer)
    ├── data/
    │   └── clubs-serie-b.js liste des clubs (éditable)
    ├── managers/
    │   ├── calendar.js     temps + événements (2 régimes)
    │   ├── player.js       joueurs (niveau global)
    │   ├── world.js        championnat, calendrier, classement
    │   ├── match.js        match du joueur (fil + résultat)
    │   └── season.js       mise en place d'une saison
    └── ui/app.js           interface (Bureau, classement, match)
```

## Prochaine étape — Phase 2
Le rôle de Président : le Board (3 objectifs, confiance, licenciement),
le Bureau enrichi, les finances de base. Le joueur passe de spectateur à
dirigeant évalué.
