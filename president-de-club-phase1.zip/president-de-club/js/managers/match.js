/* ============================================================
   managers/match.js — Le MatchManager (Phase 1)
   ------------------------------------------------------------
   Résout le match du club du joueur. Produit un RÉSULTAT et un
   FIL D'ÉVÉNEMENTS commenté (ch. 12). L'écran de match pourra
   dérouler le fil OU sauter au résultat via "Simuler" — dans
   les deux cas, le résultat final est le même (déjà calculé).
   Le Président observe : aucune action pendant le match (R001).
   ============================================================ */

const MatchManager = (function () {

  /* Résout le match du joueur.
     home/away = ids de club. Retourne :
       { homeId, awayId, homeName, awayName,
         homeGoals, awayGoals, feed: [ {minute, text}, ... ] } */
  function resolvePlayerMatch(gs, homeId, awayId) {
    const r = WorldManager.simulateMatch(gs, homeId, awayId);
    const homeName = clubName(gs, homeId);
    const awayName = clubName(gs, awayId);

    const feed = buildFeed(gs, homeId, awayId, r.homeGoals, r.awayGoals, homeName, awayName);

    // Appliquer le résultat au classement (comme pour les clubs IA).
    WorldManager.applyResult(gs, homeId, awayId, r.homeGoals, r.awayGoals);

    // Enregistrer le résultat du match du joueur (pour le calendrier).
    if (!gs.world.playerResults) gs.world.playerResults = {};
    gs.world.playerResults[gs.world.currentMatchday] = {
      matchday: gs.world.currentMatchday,
      homeId, awayId, homeName, awayName,
      homeGoals: r.homeGoals, awayGoals: r.awayGoals,
    };

    return {
      homeId, awayId, homeName, awayName,
      homeGoals: r.homeGoals, awayGoals: r.awayGoals,
      feed,
    };
  }

  /* Construit un fil d'événements plausible cohérent avec le score.
     On place les buts à des minutes aléatoires, triées, plus le
     coup d'envoi / mi-temps / coup de sifflet final. */
  function buildFeed(gs, homeId, awayId, hg, ag, homeName, awayName) {
    const goals = [];
    for (let i = 0; i < hg; i++) goals.push({ side: "home", minute: rndMinute() });
    for (let i = 0; i < ag; i++) goals.push({ side: "away", minute: rndMinute() });
    goals.sort((a, b) => a.minute - b.minute);

    const feed = [];
    feed.push({ minute: 0, text: `Coup d'envoi : ${homeName} — ${awayName}` });

    let h = 0, a = 0, halftimeInserted = false;
    for (const g of goals) {
      if (!halftimeInserted && g.minute > 45) {
        feed.push({ minute: 45, text: `Mi-temps : ${homeName} ${h} - ${a} ${awayName}` });
        halftimeInserted = true;
      }
      if (g.side === "home") h++; else a++;
      const scorer = randomScorer(gs, g.side === "home" ? homeId : awayId);
      const team = g.side === "home" ? homeName : awayName;
      feed.push({ minute: g.minute, text: `⚽ ${g.minute}' BUT pour ${team} ! (${scorer})  [${h}-${a}]` });
    }
    if (!halftimeInserted) {
      feed.push({ minute: 45, text: `Mi-temps : ${homeName} ${h} - ${a} ${awayName}` });
    }
    feed.push({ minute: 90, text: `Coup de sifflet final : ${homeName} ${hg} - ${ag} ${awayName}` });
    return feed;
  }

  function rndMinute() { return Math.floor(Math.random() * 90) + 1; }

  function randomScorer(gs, clubId) {
    // Un buteur plausible : plutôt un attaquant/milieu, sinon n'importe.
    const squad = gs.players.filter(p => p.clubId === clubId);
    const attackers = squad.filter(p => p.poste === "A" || p.poste === "M");
    const pool = attackers.length ? attackers : squad;
    if (!pool.length) return "un joueur";
    return pool[Math.floor(Math.random() * pool.length)].name;
  }

  function clubName(gs, clubId) {
    const c = gs.clubs.find(c => c.id === clubId);
    return c ? c.name : "?";
  }

  return { resolvePlayerMatch };
})();

window.MatchManager = MatchManager;
