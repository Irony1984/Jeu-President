/* ============================================================
   managers/player.js — Le PlayerManager (Phase 1, minimal)
   ------------------------------------------------------------
   Gère les joueurs. En Phase 1, un joueur = un niveau global
   (ch. 16). Pas encore de progression, cycle de vie, potentiel :
   ça viendra en Phase 3. Ici on génère seulement des effectifs
   crédibles pour pouvoir jouer des matchs.
   ============================================================ */

const PlayerManager = (function () {

  const POSTES = ["G", "D", "D", "D", "D", "M", "M", "M", "A", "A", "A"];
  const PRENOMS = ["Luca", "Marco", "Matteo", "Andrea", "Davide", "Giulio",
    "Simone", "Alessio", "Francesco", "Lorenzo", "Nicolò", "Tommaso",
    "Riccardo", "Federico", "Antonio", "Giovanni", "Stefano", "Emanuele"];
  const NOMS = ["Rossi", "Bianchi", "Ferrari", "Esposito", "Romano", "Colombo",
    "Ricci", "Marino", "Greco", "Bruno", "Gallo", "Conti", "De Luca",
    "Mancini", "Costa", "Giordano", "Rizzo", "Lombardi", "Moretti", "Barbieri"];

  let _idCounter = 1;

  function _rand(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  function _pick(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  /* Génère un joueur autour d'un niveau cible. */
  function createPlayer(clubId, poste, targetLevel) {
    // niveau = cible ± 6, borné 30-95
    let level = targetLevel + _rand(-6, 6);
    level = Math.max(30, Math.min(95, level));
    return {
      id: _idCounter++,
      name: _pick(PRENOMS) + " " + _pick(NOMS),
      clubId: clubId,
      poste: poste,
      level: level,
      age: _rand(18, 33),
      forme: 50, // forme du moment (0-100), influe la performance
    };
  }

  /* Génère un effectif complet (18 joueurs) pour un club,
     centré sur la force du club. Retourne le tableau de joueurs. */
  function generateSquad(clubId, clubStrength) {
    const squad = [];
    // 11 titulaires suivant les postes types + 7 remplaçants
    for (const poste of POSTES) {
      squad.push(createPlayer(clubId, poste, clubStrength));
    }
    for (let i = 0; i < 7; i++) {
      squad.push(createPlayer(clubId, _pick(POSTES), clubStrength - 4));
    }
    return squad;
  }

  /* Force effective d'un club = moyenne des 11 meilleurs joueurs.
     Sert au calcul du résultat des matchs. */
  function teamRating(gs, clubId) {
    const squad = gs.players.filter(p => p.clubId === clubId);
    if (squad.length === 0) return 50;
    const top = squad.slice().sort((a, b) => b.level - a.level).slice(0, 11);
    const sum = top.reduce((s, p) => s + p.level, 0);
    return Math.round(sum / top.length);
  }

  return { createPlayer, generateSquad, teamRating };
})();

window.PlayerManager = PlayerManager;
