/* ============================================================
   ui/app.js — Interface (Phase 1)
   ------------------------------------------------------------
   Le Bureau + le classement + l'écran de match (fil d'événements
   avec bouton "Simuler"). Boucle de saison jouable.
   ============================================================ */

(function () {
  const $ = (sel) => document.querySelector(sel);

  const setupEl = $("#setup");
  const gameEl = $("#game");
  const logEl = $("#log");
  const matchEl = $("#matchScreen");
  const homeEl = $("#home");
  const bilanEl = $("#bilanScreen");

  let pendingMatch = null; // match du joueur en attente d'affichage
  let pendingSlot = 1;     // slot ciblé pour une nouvelle partie
  let matchJustFinished = false; // vrai juste après un match, pour le retour Bureau

  /* --- Rendu du Bureau --- */
  function render(report) {
    const gs = GameEngine.getState();
    if (!gs) return;

    // Barre d'action selon la phase (saison ou intersaison).
    const phase = gs.time.phase || "season";
    const btnContinue = $("#btnContinue");
    const btnWeek = $("#btnWeek");
    const btnPreseason = $("#btnPreseason");
    $("#btnSimulate").classList.add("hidden");
    if (phase === "intersaison") {
      btnContinue.classList.add("hidden");
      btnWeek.classList.remove("hidden");
      btnPreseason.classList.remove("hidden");
    } else {
      btnContinue.classList.remove("hidden");
      btnWeek.classList.add("hidden");
      btnPreseason.classList.add("hidden");
    }

    $("#clubName").textContent = gs.club.name || "—";
    $("#reputation").textContent = labelRep(gs.president.reputation);
    $("#date").textContent = formatDate(gs.time.currentDate);
    $("#cash").textContent = gs.club.cash + " M";
    $("#confidence").textContent = gs.board.confidence + "/100";
    $("#season").textContent = "Saison " + gs.time.season;

    const badge = $("#mercatoBadge");
    if (phase === "intersaison") {
      badge.textContent = "Intersaison"; badge.classList.remove("off");
    } else if (gs.time.inMercato) {
      badge.textContent = "Mercato ouvert"; badge.classList.remove("off");
    } else {
      badge.textContent = "Hors mercato"; badge.classList.add("off");
    }

    if (report) addLogLine(report);

    // Cadre "prochain match" (masqué en intersaison).
    const nmCard = $("#nextMatchCard");
    const nm = $("#nextMatch");
    if (phase === "intersaison") {
      nmCard.classList.add("hidden");
    } else {
      nmCard.classList.remove("hidden");
      const next = WorldManager.getNextPlayerMatch(gs);
      if (next) {
        const lieu = next.isHome ? "à domicile" : "à l'extérieur";
        nm.innerHTML =
          `<span class="nm-opp">${next.opponent}</span>` +
          `<span class="nm-info">${lieu} · ${formatDate(next.date)} · J${next.matchday + 1}</span>`;
      } else {
        nm.textContent = "Aucun match à venir cette saison.";
      }
    }
  }

  /* --- Classement (rendu dans une table cible) --- */
  function renderStandingsInto(selector) {
    const gs = GameEngine.getState();
    if (!gs || !gs.world || !gs.world.standings) return;
    const rows = WorldManager.getStandings(gs);
    const body = $(selector);
    body.innerHTML = "";
    for (const r of rows) {
      const tr = document.createElement("tr");
      if (r.isPlayer) tr.className = "me";
      tr.innerHTML =
        `<td>${r.rank}</td>` +
        `<td class="tname">${r.name}</td>` +
        `<td>${r.played}</td>` +
        `<td>${r.won}-${r.drawn}-${r.lost}</td>` +
        `<td>${r.gf - r.ga >= 0 ? "+" : ""}${r.gf - r.ga}</td>` +
        `<td class="pts">${r.points}</td>`;
      body.appendChild(tr);
    }
  }

  /* --- Calendrier regroupé par mois --- */
  function renderCalendar() {
    const gs = GameEngine.getState();
    const body = $("#calendarBody");
    body.innerHTML = "";

    const MOIS = ["", "Janvier", "Février", "Mars", "Avril", "Mai", "Juin",
      "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];

    // 1. Rassembler tous les éléments datés : matchs, mercato, fin de saison.
    const items = [];

    // Matchs du joueur.
    const cal = WorldManager.getPlayerCalendar(gs);
    for (const m of cal) {
      if (!m.date) continue;
      items.push({
        date: m.date,
        kind: "match",
        played: m.played,
        text: m.isHome ? `vs ${m.opponent} (dom.)` : `à ${m.opponent} (ext.)`,
        score: m.played && m.result
          ? (m.isHome
              ? `${m.result.homeGoals}-${m.result.awayGoals}`
              : `${m.result.awayGoals}-${m.result.homeGoals}`)
          : null,
      });
    }

    // Fenêtres de mercato (été : juil-août ; hiver : janvier) de la saison.
    // On repère l'année de la saison à partir du 1er match.
    const firstDate = cal.find(m => m.date)?.date;
    if (firstDate) {
      const y = Number(firstDate.split("-")[0]);
      items.push({ date: `${y}-07-01`, kind: "mercato", text: "Ouverture du mercato d'été" });
      items.push({ date: `${y}-08-31`, kind: "mercato", text: "Fermeture du mercato d'été" });
      items.push({ date: `${y + 1}-01-01`, kind: "mercato", text: "Ouverture du mercato d'hiver" });
      items.push({ date: `${y + 1}-01-31`, kind: "mercato", text: "Fermeture du mercato d'hiver" });
    }

    // Fin de saison.
    if (gs.world.seasonEndDate) {
      items.push({ date: gs.world.seasonEndDate, kind: "end", text: "Fin de saison" });
    }

    // 2. Trier par date et regrouper par mois (année-mois).
    items.sort((a, b) => CalendarManager.compare(a.date, b.date));
    const curYM = gs.time.currentDate.slice(0, 7);

    let currentGroup = null;
    let groupEl = null;
    for (const it of items) {
      const ym = it.date.slice(0, 7);
      if (ym !== currentGroup) {
        currentGroup = ym;
        const [yy, mm] = ym.split("-");
        const header = document.createElement("div");
        header.className = "cal-month" + (ym === curYM ? " current" : "");
        header.textContent = `${MOIS[Number(mm)]} ${yy}` + (ym === curYM ? "  • en cours" : "");
        body.appendChild(header);
        groupEl = document.createElement("div");
        groupEl.className = "cal-items";
        body.appendChild(groupEl);
      }
      const row = document.createElement("div");
      row.className = "cal-row " + it.kind + (it.played ? " played" : "");
      const day = Number(it.date.split("-")[2]);
      let icon = it.kind === "match" ? "⚽" : it.kind === "mercato" ? "🔁" : "🏁";
      let right = "";
      if (it.kind === "match" && it.played) right = `<span class="cal-score">${it.score}</span>`;
      row.innerHTML =
        `<span class="cal-day">${day}</span>` +
        `<span class="cal-icon">${icon}</span>` +
        `<span class="cal-text">${it.text}</span>` +
        right;
      groupEl.appendChild(row);
    }

    if (items.length === 0) {
      body.innerHTML = `<p class="soon">Aucun événement au calendrier pour le moment.</p>`;
    }
  }
  function renderSquad() {
    const gs = GameEngine.getState();
    const body = $("#squadBody");
    body.innerHTML = "";
    const squad = gs.players
      .filter(p => p.clubId === gs.club.id)
      .sort((a, b) => b.level - a.level);
    const ordre = { G: 0, D: 1, M: 2, A: 3 };
    squad.sort((a, b) => (ordre[a.poste] - ordre[b.poste]) || (b.level - a.level));
    for (const p of squad) {
      const tr = document.createElement("tr");
      tr.className = "clickable";
      tr.innerHTML =
        `<td>${p.poste}</td>` +
        `<td class="tname">${p.name}</td>` +
        `<td>${p.age}</td>` +
        `<td class="pts">${p.level}</td>`;
      tr.addEventListener("click", () => openPlayerDetail(p));
      body.appendChild(tr);
    }
  }

  /* Fiche détaillée d'un joueur (Phase 1 : données de base). */
  function openPlayerDetail(p) {
    hideAll();
    const posteNom = { G: "Gardien", D: "Défenseur", M: "Milieu", A: "Attaquant" };
    $("#pdName").textContent = p.name;
    $("#pdBody").innerHTML =
      `<div class="pd-row"><span>Poste</span><b>${posteNom[p.poste] || p.poste}</b></div>` +
      `<div class="pd-row"><span>Âge</span><b>${p.age} ans</b></div>` +
      `<div class="pd-row"><span>Niveau</span><b>${p.level}</b></div>` +
      `<p class="soon">Le potentiel, la forme et les autres attributs seront visibles dans les phases suivantes.</p>`;
    $("#screenPlayer").classList.remove("hidden");
  }

  /* --- Journal --- */
  function addLogLine(report) {
    const empty = logEl.querySelector(".empty");
    if (empty) empty.remove();
    const li = document.createElement("li");
    li.innerHTML = `<span class="when">${formatDate(report.date)}</span>` +
                   `<span class="what">${report.label || "…"}</span>`;
    logEl.prepend(li);
    while (logEl.children.length > 12) logEl.removeChild(logEl.lastChild);
  }

  function labelRep(r) {
    return r === "legende" ? "Légende" : r === "confirme" ? "Confirmé" : "Amateur";
  }
  function formatDate(str) {
    if (!str) return "—";
    const [y, m, d] = str.split("-");
    const mois = ["", "janv.", "févr.", "mars", "avr.", "mai", "juin",
      "juil.", "août", "sept.", "oct.", "nov.", "déc."];
    return `${Number(d)} ${mois[Number(m)]} ${y}`;
  }

  /* --- Écran de match : fil d'événements + Simuler --- */
  function openMatchScreen(playerMatch) {
    pendingMatch = playerMatch;
    const gs = GameEngine.getState();
    // Résoudre le match maintenant (résultat déjà calculé) ;
    // on déroule ensuite le fil, ou on saute au résultat.
    GameEngine.resolvePlayerMatch(playerMatch).then((result) => {
      showMatch(result);
    });
  }

  function showMatch(result) {
    gameEl.classList.add("hidden");
    matchEl.classList.remove("hidden");
    $("#actionbar").classList.remove("hidden");
    $("#matchTitle").textContent = `${result.homeName} — ${result.awayName}`;
    $("#matchScore").textContent = "0 - 0";
    const feedEl = $("#matchFeed");
    feedEl.innerHTML = "";

    // Pendant le match : seul "Simuler" est visible. "Continuer" et
    // les boutons d'intersaison sont cachés.
    const btnContinue = $("#btnContinue");
    const btnSimulate = $("#btnSimulate");
    $("#btnWeek").classList.add("hidden");
    $("#btnPreseason").classList.add("hidden");
    btnContinue.classList.add("hidden");
    btnSimulate.classList.remove("hidden");

    let i = 0;
    let timer = null;
    let finished = false;
    const feed = result.feed;

    function step() {
      if (i >= feed.length) { finishMatch(result); return; }
      const e = feed[i++];
      const li = document.createElement("li");
      li.textContent = e.text;
      feedEl.appendChild(li);
      feedEl.scrollTop = feedEl.scrollHeight;
      const mm = e.text.match(/\[(\d+)-(\d+)\]/);
      if (mm) $("#matchScore").textContent = `${mm[1]} - ${mm[2]}`;
    }

    // Déroulé automatique (1 ligne / 700ms)
    timer = setInterval(step, 700);

    // "Simuler" : saute directement au résultat final.
    btnSimulate.onclick = () => {
      clearInterval(timer);
      while (i < feed.length) {
        const e = feed[i++];
        const li = document.createElement("li");
        li.textContent = e.text;
        feedEl.appendChild(li);
      }
      $("#matchScore").textContent = `${result.homeGoals} - ${result.awayGoals}`;
      feedEl.scrollTop = feedEl.scrollHeight;
      finishMatch(result);
    };

    // Quand le match est fini : cacher "Simuler", remontrer "Continuer"
    // qui, cette fois, ferme l'écran de match et revient au Bureau.
    function finishMatch(res) {
      if (finished) return;
      finished = true;
      if (timer) clearInterval(timer);
      $("#matchScore").textContent = `${res.homeGoals} - ${res.awayGoals}`;
      btnSimulate.classList.add("hidden");
      btnContinue.classList.remove("hidden");
      // On passe en mode "match terminé" : le prochain clic sur
      // Continuer FERME le match et revient au Bureau, sans avancer
      // le temps (c'est onContinue qui vérifie ce drapeau).
      matchJustFinished = true;
    }
  }

  /* --- Navigation entre écrans --- */
  function hideAll() {
    homeEl.classList.add("hidden");
    setupEl.classList.add("hidden");
    matchEl.classList.add("hidden");
    gameEl.classList.add("hidden");
    bilanEl.classList.add("hidden");
    $("#campScreen").classList.add("hidden");
    document.querySelectorAll(".subscreen").forEach(el => el.classList.add("hidden"));
    $("#actionbar").classList.add("hidden");
  }

  /* Ouvre un sous-écran depuis le Bureau (classement, équipe, etc.). */
  function openScreen(name) {
    hideAll();
    const map = {
      calendar: "#screenCalendar",
      standings: "#screenStandings",
      squad: "#screenSquad",
      staff: "#screenStaff",
      infra: "#screenInfra",
      finances: "#screenFinances",
    };
    const sel = map[name];
    if (!sel) { showGame(); return; }
    if (name === "calendar") renderCalendar();
    if (name === "standings") renderStandingsInto("#standingsBody");
    if (name === "squad") renderSquad();
    $(sel).classList.remove("hidden");
  }
  function showHome() {
    hideAll();
    homeEl.classList.remove("hidden");
    renderHome();
  }
  async function showSetup(slot) {
    hideAll();
    pendingSlot = slot;
    setupEl.classList.remove("hidden");

    // Verrouiller les niveaux de réputation selon l'XP globale.
    let total = 0;
    try { total = (await Storage.getProfile()).totalSeasons || 0; } catch (_) {}
    const sel = $("#inReputation");
    const levels = [
      { value: "amateur", label: "Amateur", need: 0 },
      { value: "confirme", label: "Confirmé", need: 5 },
      { value: "legende", label: "Légende", need: 10 },
    ];
    sel.innerHTML = "";
    for (const lv of levels) {
      const unlocked = total >= lv.need;
      const opt = document.createElement("option");
      opt.value = lv.value;
      opt.textContent = unlocked
        ? lv.label
        : `${lv.label} 🔒 (${lv.need} saisons)`;
      opt.disabled = !unlocked;
      sel.appendChild(opt);
    }
    sel.value = "amateur";
    // Petit rappel d'XP sous le sélecteur.
    const hint = $("#repHint");
    if (hint) {
      hint.textContent = total >= 10
        ? "Tous les niveaux sont débloqués."
        : total >= 5
        ? `Expérience : ${total} saisons. « Légende » à 10 saisons.`
        : `Expérience : ${total} saison(s). « Confirmé » à 5, « Légende » à 10.`;
    }
  }
  function showGame() {
    hideAll();
    gameEl.classList.remove("hidden");
    $("#actionbar").classList.remove("hidden");
  }

  /* --- Écran d'accueil : liste des slots --- */
  async function renderHome() {
    const listEl = $("#slotList");
    listEl.innerHTML = "";
    const slots = await Storage.listSlots();
    for (const s of slots) {
      const card = document.createElement("div");
      card.className = "slot" + (s.empty ? " empty" : "");
      if (s.empty) {
        card.innerHTML =
          `<div class="slot-title">Slot ${s.slot}</div>` +
          `<div class="slot-sub">Emplacement vide</div>`;
        const btn = document.createElement("button");
        btn.className = "primary";
        btn.textContent = "Nouvelle partie";
        btn.onclick = () => showSetup(s.slot);
        card.appendChild(btn);
      } else {
        const sm = s.summary;
        card.innerHTML =
          `<div class="slot-title">${sm.clubName}</div>` +
          `<div class="slot-sub">${capitalize(sm.country)} · Saison ${sm.season} · ${formatDate(sm.date)}</div>`;
        const row = document.createElement("div");
        row.className = "slot-actions";
        const bResume = document.createElement("button");
        bResume.className = "primary";
        bResume.textContent = "Reprendre";
        bResume.onclick = () => resumeSlot(s.slot);
        const bDel = document.createElement("button");
        bDel.className = "ghost danger";
        bDel.textContent = "Supprimer";
        bDel.onclick = () => deleteSlot(s.slot);
        row.appendChild(bResume);
        row.appendChild(bDel);
        card.appendChild(row);
      }
      listEl.appendChild(card);
    }
  }

  function capitalize(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : "—"; }

  /* --- Créer une nouvelle partie dans le slot choisi --- */
  async function startNewGame() {
    const clubName = $("#inClub").value.trim() || "FC Vallonne";
    const city = $("#inCity").value.trim() || "";
    const gs = createNewGame({
      presidentName: $("#inPresident").value.trim() || "Président",
      clubName: clubName,
      country: "italie",
      reputation: $("#inReputation").value,
    });
    SeasonManager.startSeason(gs, CLUBS_SERIE_B, { name: clubName, city: city });
    GameEngine.attach(gs, pendingSlot);
    await Storage.saveSlot(pendingSlot, gs);
    showGame();
    render(null);
  }

  /* --- Reprendre une partie existante --- */
  async function resumeSlot(slot) {
    const gs = await Storage.loadSlot(slot);
    if (!gs) { showHome(); return; }
    GameEngine.attach(gs, slot);
    showGame();
    render(null);
  }

  /* --- Supprimer une partie (le vrai "recommencer") --- */
  async function deleteSlot(slot) {
    if (!confirm(`Supprimer définitivement la partie du slot ${slot} ?`)) return;
    await Storage.deleteSlot(slot);
    renderHome();
  }

  /* --- Bouton Continuer --- */
  async function onContinue() {
    // Si un match vient de se terminer, ce clic FERME le match et
    // revient au Bureau — SANS avancer le temps (1 clic = 1 match).
    if (matchJustFinished) {
      matchJustFinished = false;
      matchEl.classList.add("hidden");
      showGame();
      render(null);
      return;
    }
    const btn = $("#btnContinue");
    btn.disabled = true;
    try {
      const report = await GameEngine.continueStep();
      if (report.openMatch && report.playerMatch) {
        addLogLine(report);
        openMatchScreen(report.playerMatch);
      } else if (report.seasonEnd) {
        addLogLine(report);
        showBilan();
      } else {
        render(report);
      }
    } catch (e) {
      console.error(e); alert("Erreur : " + e.message);
    } finally {
      btn.disabled = false;
    }
  }

  /* --- Écran de bilan de fin de saison --- */
  async function showBilan() {
    hideAll();
    bilanEl.classList.remove("hidden");
    const gs = GameEngine.getState();
    const rows = WorldManager.getStandings(gs);
    const me = rows.find(r => r.isPlayer);

    // Compter cette saison dans l'XP globale du joueur.
    let total = 0;
    try { total = await Storage.addSeasonPlayed(); } catch (_) {}

    $("#bilanTitle").textContent = `Fin de la saison ${gs.time.season}`;
    let summary = `${me.name} termine ${me.rank}ᵉ sur ${rows.length} avec ${me.points} points.`;
    // Message de déblocage de réputation, le cas échéant.
    if (total === 5) summary += ` 🎉 Vous avez débloqué le niveau « Confirmé » !`;
    if (total === 10) summary += ` 🏆 Vous avez débloqué le niveau « Légende » !`;
    summary += `\nExpérience : ${total} saison${total > 1 ? "s" : ""} jouée${total > 1 ? "s" : ""} au total.`;
    $("#bilanSummary").textContent = summary;

    const body = $("#bilanStandings");
    body.innerHTML = "";
    for (const r of rows) {
      const tr = document.createElement("tr");
      if (r.isPlayer) tr.className = "me";
      tr.innerHTML =
        `<td>${r.rank}</td><td class="tname">${r.name}</td>` +
        `<td>${r.played}</td><td>${r.won}-${r.drawn}-${r.lost}</td>` +
        `<td>${r.gf - r.ga >= 0 ? "+" : ""}${r.gf - r.ga}</td>` +
        `<td class="pts">${r.points}</td>`;
      body.appendChild(tr);
    }
  }

  async function onNextSeason() {
    const btn = $("#btnNextSeason");
    btn.disabled = true;
    try {
      await GameEngine.enterIntersaison();
      showGame();
      render(null);
    } catch (e) {
      console.error(e); alert("Erreur : " + e.message);
    } finally {
      btn.disabled = false;
    }
  }

  /* Avancer d'une semaine pendant l'intersaison. */
  async function onAdvanceWeek() {
    const btn = $("#btnWeek");
    btn.disabled = true;
    try {
      const rep = await GameEngine.advanceWeek();
      // Un stage de préparation ? Ouvrir l'écran de décision.
      if (rep.trainingCamp) {
        showCampScreen();
        return;
      }
      for (const m of rep.messages) {
        addLogLine({ date: m.date, label: m.label });
      }
      if (rep.reachedPreseason) {
        await GameEngine.goToPreseason();
        addLogLine({ date: GameEngine.getState().time.currentDate, label: "Début de la pré-saison" });
      }
      render(null);
    } catch (e) {
      console.error(e); alert("Erreur : " + e.message);
    } finally {
      btn.disabled = false;
    }
  }

  /* Écran de décision du stage de préparation. */
  function showCampScreen() {
    hideAll();
    const gs = GameEngine.getState();
    $("#campCash").textContent = gs.club.cash + " M";
    const opts = [
      { level: "eco", name: "Stage économique", cost: 1, desc: "Petit gain de forme" },
      { level: "standard", name: "Stage standard", cost: 2.5, desc: "Bon gain de forme" },
      { level: "luxe", name: "Stage de luxe", cost: 4, desc: "Fort gain de forme" },
      { level: "none", name: "Aucun stage", cost: 0, desc: "Aucun gain" },
    ];
    const wrap = $("#campOptions");
    wrap.innerHTML = "";
    for (const o of opts) {
      const affordable = o.cost <= gs.club.cash;
      const card = document.createElement("button");
      card.className = "camp-opt" + (affordable ? "" : " disabled");
      card.disabled = !affordable;
      card.innerHTML =
        `<div class="camp-opt-head"><span class="camp-name">${o.name}</span>` +
        `<span class="camp-cost">${o.cost === 0 ? "Gratuit" : o.cost + " M"}</span></div>` +
        `<div class="camp-desc">${o.desc}${affordable ? "" : " — trésorerie insuffisante"}</div>`;
      if (affordable) card.onclick = () => onChooseCamp(o.level);
      wrap.appendChild(card);
    }
    $("#campScreen").classList.remove("hidden");
  }

  async function onChooseCamp(level) {
    try {
      const res = await GameEngine.chooseTrainingCamp(level);
      if (!res.ok) { alert("Trésorerie insuffisante."); return; }
      const gs = GameEngine.getState();
      const label = level === "none"
        ? "Stage de préparation : aucun stage retenu"
        : `Stage de préparation effectué (-${res.cost} M, forme +${res.bonus})`;
      addLogLine({ date: gs.time.currentDate, label });
      // Reprendre l'intersaison (retour au Bureau).
      showGame();
      render(null);
    } catch (e) {
      console.error(e); alert("Erreur : " + e.message);
    }
  }

  /* Passer directement à la pré-saison (saute l'intersaison). */
  async function onSkipToPreseason() {
    const btn = $("#btnPreseason");
    btn.disabled = true;
    try {
      await GameEngine.goToPreseason();
      addLogLine({ date: GameEngine.getState().time.currentDate, label: "Nouvelle saison — pré-saison" });
      render(null);
    } catch (e) {
      console.error(e); alert("Erreur : " + e.message);
    } finally {
      btn.disabled = false;
    }
  }

  /* Bouton retour à l'accueil depuis une partie. */
  function onHome() {
    showHome();
  }

  async function init() {
    $("#btnStart").addEventListener("click", startNewGame);
    $("#btnSetupBack").addEventListener("click", showHome);
    $("#btnContinue").addEventListener("click", onContinue);
    $("#btnNextSeason").addEventListener("click", onNextSeason);
    $("#btnWeek").addEventListener("click", onAdvanceWeek);
    $("#btnPreseason").addEventListener("click", onSkipToPreseason);
    $("#btnReset").addEventListener("click", onHome);
    $("#btnPlayerBack").addEventListener("click", () => openScreen("squad"));
    // Boutons de navigation du Bureau vers les sous-écrans.
    document.querySelectorAll(".navbtn").forEach(btn => {
      btn.addEventListener("click", () => openScreen(btn.dataset.screen));
    });
    // Boutons "retour au Bureau" des sous-écrans.
    document.querySelectorAll(".btnBack").forEach(btn => {
      btn.addEventListener("click", () => { showGame(); render(null); });
    });
    // Au lancement : toujours l'écran d'accueil (menu des slots).
    try {
      showHome();
    } catch (e) {
      console.error("Init :", e);
      showHome();
    }
  }

  // Le script est chargé en fin de <body> : DOMContentLoaded peut
  // avoir DÉJÀ été déclenché. On lance init() tout de suite dans ce
  // cas, sinon on attend l'événement.
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
